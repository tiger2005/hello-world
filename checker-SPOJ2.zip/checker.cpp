#include"testlib.h"
#include<cstdio>
#include<cstring>
using namespace std;
char lo[1000000];
int by[10000000],now,nnn,q,xh,xx,yy,lx;
bool aaa=true;
int aaaa,bbb,ccc,ddd,aa,bb;
int sj,now1,now2,ans1,ans2,suan,haha;
char ssj[1000],ssjj[1000];
void co(int be,int en){
    if(be>en){
        quitf(_wa,"Fell in endless loop at No. %d...",be-1);
        aaa=false;
        return;
    }
    int nn=be;
    while(nn<=en&&aaa){
        if(lo[nn]=='<'){
            --now;
            if(now==0){
                quitf(_wa,"Point to the undefination byte at No. %d...",nn);
                aaa=false;
                if(!aaa)	return;
            }
        }
        else if(lo[nn]=='>'){
            ++now;
            if(now>10000000){
                quitf(_wa,"Point to the undefination byte at No. %d...",nn);
                aaa=false;
                if(!aaa)	return;
            }
        }
        else if(lo[nn]=='+'){
            ++by[now];
            while(by[now]<0)    by[now]+=256;
            while(by[now]>255)  by[now]-=256;
        }
        else if(lo[nn]=='-'){
            --by[now];
            while(by[now]<0)    by[now]+=256;
            while(by[now]>255)  by[now]-=256;
    	}
        else if(lo[nn]=='.'){
        	char as=ans.readChar();
        	if(as==10)	quitf(_wa,"Wrong answer!"); 
			if(as=='`')	as=10;
			if(by[now]!=as)	quitf(_wa,"Wrong answer!"); 
        }
        else if(lo[nn]==','){
        	by[now]=inf.readChar();
			if(by[now]==10)	quitf(_wa,"Cannot read at No. %d...",nn);
			else{
        		if(by[now]=='`')	by[now]=10;
			}
        }
        else if(lo[nn]=='['){
            int nnn=nn+1,no=1;
            while(no!=0 && nnn<=en){
                if(lo[nnn]=='[')    ++no;
                if(lo[nnn]==']')    --no;
                ++nnn;
            }
            if(nnn!=en+1||no==0){
                while(by[now]){
                	++xh;
                	if(xh>10000000){
                		quitf(_wa,"Fell in more than 10000000 loops in No. %d",nn-1);
                		aaa=false;
                		return;
					}
                	co(nn+1,nnn-2);
				}
            }
            else{
                quitf(_wa,"Cannot find the last part in No. %d...",nn);
                aaa=false;
                if(!aaa)	return;
            }
            if(!aaa)	return;
            nn=nnn-1;
        }
        else if(lo[nn]==']'){
			quitf(_wa,"Cannot find the last part in No. %d...",nn);
            aaa=false;
            if(!aaa)	return;
        }
        ++nn;
    }
}
int main(int argc, char* argv[]){
	registerTestlibCmd(argc, argv);
	char h;
	q=0;
	while(h!=10){
		h=ouf.readChar();
		lo[++q]=h;
	}
	memset(by,0,sizeof(by));
    aaa=true;
    now=5000; 
    co(1,q);
    quitf(_ok,"Answer correct ! ");
    return 0;
}
