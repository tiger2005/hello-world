#include"testlib.h"
#include<cstdio>
#include<cstring>
using namespace std;
char lo[1000000];
int by[100000000],now,nnn,q,xh,xx,yy,lx;
bool aaa=true;
int aaaa,bbb,ccc,ddd,aa,bb;
int sj,now1,now2,ans1,ans2,suan,haha;
char ssj[1000],ssjj[1000];
void co(int be,int en){
    if(be>en){
        quitf(_wa,"Fell in endless loop at No. %d...",be-1);
        aaa=false;
        return;
    }
    int nn=be;
    while(nn<=en&&aaa){
        if(lo[nn]=='<'){
            --now;
            if(now==0){
                quitf(_wa,"Point to the undefination byte at No. %d...",nn);
                aaa=false;
                if(!aaa)	return;
            }
        }
        else if(lo[nn]=='>'){
            ++now;
            if(now>100000000){
                quitf(_wa,"Point to the undefination byte at No. %d...",nn);
                aaa=false;
                if(!aaa)	return;
            }
        }
        else if(lo[nn]=='+'){
            ++by[now];
            while(by[now]<0)    by[now]+=128;
            while(by[now]>127)  by[now]-=128;
        }
        else if(lo[nn]=='-'){
            --by[now];
            while(by[now]<0)    by[now]+=128;
            while(by[now]>127)  by[now]-=128;
    	}
        else if(lo[nn]=='.'){
        	if(ssjj[now2]==100){
        		suan=32;
        		++now2;
			}
			else if(ssjj[now2]>9){
				suan=ssjj[now2]/10+48;
				ssjj[now2]%=10;
			}
			else{
				suan=ssjj[now2]+48;
				ssjj[now2]=100;
			}
        	if(by[now]==10)	quitf(_wa,"Wrong in line 1");
        	else if(by[now]!=10&&suan!=by[now])	quitf(_wa,"Wrong in the %d th number",now2+1);
        }
        else if(lo[nn]==','){
			if(now1>=lx)	quitf(_wa,"Cannot read at No. %d...",nn);
        	if(ssj[now1]==100){
        		suan=32;
        		++now1;
			}
			else if(ssj[now1]>9){
				suan=ssj[now1]/10+48;
				ssj[now1]%=10;
			}
			else{
				suan=ssj[now1]+48;
				ssj[now1]=100;
			}
        	by[now]=suan;
        }
        else if(lo[nn]=='['){
            int nnn=nn+1,no=1;
            while(no!=0 && nnn<=en){
                if(lo[nnn]=='[')    ++no;
                if(lo[nnn]==']')    --no;
                ++nnn;
            }
            if(nnn!=en+1||no==0){
                while(by[now]){
                	++xh;
                	if(xh>1000000){
                		quitf(_wa,"Fell in more than 1000000 loops in No. %d",nn-1);
                		aaa=false;
                		return;
					}
                	co(nn+1,nnn-2);
				}
            }
            else{
                quitf(_wa,"Cannot find the last part in No. %d...",nn);
                aaa=false;
                if(!aaa)	return;
            }
            if(!aaa)	return;
            nn=nnn-1;
        }
        else if(lo[nn]==']'){
			quitf(_wa,"Cannot find the last part in No. %d...",nn);
            aaa=false;
            if(!aaa)	return;
        }
        ++nn;
    }
}
int main(int argc, char* argv[]){
	registerTestlibCmd(argc, argv);
	char h;
	while(h!=10){
		h=ouf.readChar();
		lo[++q]=h;
	}
	for(int i=q;i>=1;i--){
		lo[i]=lo[i-1];
		lo[i-1]=0;
	}
	memset(by,0,sizeof(by));
    aaa=true;
    now1=0;
    do{
    	haha=inf.readInt();
    	ssj[now1]=haha;
    	++now1;
	}while(haha!=0);
	for(int i=0;i<now1-1;i++)	ssjj[now1-i-2]=ssj[i];
	lx=now1;
	if(lx==1)	ssjj[0]=0;
	now1=0;
	now2=0;
    now=1;
    co(1,q);
    if((ssjj[now2]!=0&&now2==lx-2)||(ssjj[0]==0&&lx==1))	quitf(_ok,"Answer correct ! ");
    quitf(_pe,"You stop at the %d th number and you must print less/more thing...",now2);
    return 0;
}
